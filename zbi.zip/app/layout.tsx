import type { Metadata } from 'next'
import './globals.css'
import { Navbar, SideNavbar } from '@/components/navigation'

export const metadata: Metadata = {
  title: 'v0 App',
  description: 'Created with v0',
  generator: 'v0.dev',
}
interface Section {
  id: string
  label: string
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  
  const sections: Section[] = [
    { id: "hero", label: "Nature" },
    { id: "what-we-do", label: "Science" },
    { id: "innovation", label: "Innovation" },
    { id: "process", label: "Process" },
    { id: "impact", label: "Impact" },
    { id: "forager", label: "Forager" },
  ];
  return (
    <html lang="en">
      <body>
      <Navbar/>
      <SideNavbar sections={sections} />
        {children}</body>
    </html>
  )
}
